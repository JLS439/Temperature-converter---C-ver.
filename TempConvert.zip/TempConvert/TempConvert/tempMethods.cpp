#include "pch.h"
#include "tempMethods.h"
long double FtoK(long double tempKnown) {
	long double temporary = FtoC(tempKnown);
	double resultTemp = temporary + 273.15;
	return resultTemp;
}
long double CtoF(long double tempKnown) {
	long double resultTemp = (tempKnown * (9.0 / 5)) + 32;
	return resultTemp;
}
long double CtoK(long double tempKnown) {
	double resultTemp = tempKnown + 273.15;
	return resultTemp;
}
long double KtoF(long double tempKnown) {
	long double temporary = tempKnown - 273.15;
	long double resultTemp = CtoF(temporary);
	return resultTemp;
}
long double KtoC(long double tempKnown) {
	double resultTemp = tempKnown - 273.15;
	return resultTemp;
}
long double FtoC(long double tempKnown) {
	double resultTemp = ((tempKnown - 32)*5.0) / 9;
	return resultTemp;
}
long double RtoC(long double tempKnown) {
	long double resultTemp = tempKnown * (5.0 / 4);
	return resultTemp;
}
long double RtoK(long double tempKnown) {
	long double temporary = RtoC(tempKnown);
	long double resultTemp = CtoK(temporary);
	return resultTemp;
}
long double RtoF(long double tempKnown) {
	long double temporary = RtoC(tempKnown);
	long double resultTemp = CtoF(temporary);
	return resultTemp;
}
long double FtoR(long double tempKnown) {
	long double temporary = FtoC(tempKnown);
	long double resultTemp = CtoR(temporary);
	return resultTemp;
}
long double KtoR(long double tempKnown) {
	long double temporary = KtoC(tempKnown);
	long double resultTemp = CtoR(temporary);
	return resultTemp;
}
long double CtoR(long double tempKnown) {
	long double resultTemp = tempKnown * (4.0 / 5);
	return resultTemp;
}
long double FtoRA(long double tempKnown) {
	long double resultTemp = tempKnown + 459.67;
	return resultTemp;
}
long double CtoRA(long double tempKnown) {
	long double temporary = CtoF(tempKnown);
	long double resultTemp = FtoRA(temporary);
	return resultTemp;
}
long double KtoRA(long double tempKnown) {
	double temporary = KtoF(tempKnown);
	double resultTemp = FtoRA(temporary);
	return resultTemp;
}
long double RtoRA(long double tempKnown) {
	long double temporary = RtoF(tempKnown);
	long double resultTemp = FtoRA(tempKnown);
	return resultTemp;
}
long double RAtoF(long double tempKnown) {
	long double resultTemp = tempKnown - 459.57;
	return resultTemp;
}
long double RAtoC(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoC(temporary);
	return resultTemp;
}
long double RAtoK(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoK(temporary);
	return resultTemp;
}
long double RAtoR(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoR(temporary);
	return resultTemp;
}
long double FtoN(long double tempKnown) {
	long double resultTemp = (((tempKnown - 32) * 11.0) / 60);
	return resultTemp;
}
long double CtoN(long double tempKnown) {
	long double temporary = CtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double KtoN(long double tempKnown) {
	long double temporary = KtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double RtoN(long double tempKnown) {
	long double temporary = RtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double RAtoN(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double NtoF(long double tempKnown) {
	long double resultTemp = (((tempKnown *60.0) / 11) + 32);
	return resultTemp;
}
long double NtoC(long double tempKnown) {
	long double temporary = NtoF(tempKnown);
	long double resultTemp = FtoC(temporary);
	return resultTemp;
}
long double NtoK(long double tempKnown) {
	long double temporary = NtoF(tempKnown);
	long double resultTemp = FtoK(temporary);
	return resultTemp;
}
long double NtoR(long double tempKnown) {
	long double temporary = NtoF(tempKnown);
	long double resultTemp = FtoR(temporary);
	return resultTemp;
}
long double NtoRA(long double tempKnown) {
	double temporary = NtoF(tempKnown);
	double resultTemp = FtoRA(temporary);
	return resultTemp;
}