// TempConvert.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <cstring>
#include <string>
#include "tempMethods.h"
using namespace std;
int main()
{
	char continueLoop = 'Y';
	long double temporary = 0;
	long double tempKnown; //numerical unit for conversion
	char tempKnownUnit = 'K'; //Unit for known temperature
	long double resultTemp = 0; // numerical value for result of conversion 
	char resultTempUnit = 'F'; //unit for display of conversion result
	cout << "Welcome to the temperature converter!" << endl;
	for (int i = 0; i <= 2; i++) {
		cout << endl;
	}
	while (continueLoop == 'Y') {
		cout << "Please select starting unit (F = Fahrenheit, C= Celcius, K= Kelvin, R= Reaumur, A= Rankine, N = Newton) " << endl;
		cin >> tempKnownUnit;
		tempKnownUnit = toupper(tempKnownUnit);
		cout << tempKnownUnit << " is the starting unit for conversion." << endl;

		cout << "Please input a temperature in " << tempKnownUnit << endl;
		cin >> tempKnown;

		cout << "Please select resulting unit (F = Fahrenheit, C= Celcius, K= Kelvin, R= Reaumur, A= Rankine, N = Newton)" << endl;
		cin >> resultTempUnit;
		resultTempUnit = toupper(resultTempUnit);
		cout << "result will be in " << resultTempUnit << endl;

		if (tempKnownUnit == 'F' && resultTempUnit == 'K') {
			resultTemp = FtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'F') {
			resultTemp = CtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'K') {
			resultTemp = CtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'C') {
			resultTemp = KtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'C') {
			resultTemp = FtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'F') {
			resultTemp = KtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'C') {
			resultTemp = RtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'F') {
			resultTemp = RtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'K') {
			resultTemp = RtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'R') {
			resultTemp = CtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'R') {
			resultTemp = KtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'R') {
			resultTemp = FtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'A') {
			resultTemp = FtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'F') {
			resultTemp = RAtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'A') {
			resultTemp = CtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'A') {
			resultTemp = KtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'A') {
			resultTemp = RtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'C') {
			resultTemp = RAtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'K') {
			resultTemp = RAtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'R') {
			resultTemp = RAtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'N') {
			resultTemp = FtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'N') {
			resultTemp = CtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'N') {
			resultTemp = KtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'N') {
			resultTemp = RtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'N') {
			resultTemp = RAtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'F') {
			resultTemp = NtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'C') {
			resultTemp = NtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'K') {
			resultTemp = NtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'R') {
			resultTemp = NtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'A') {
			resultTemp = NtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == resultTempUnit) {
		cout << "Whoops!  You entered the same unit twice!  Therefore, the temperatures are the same when 'converted'." << endl;
		}
		else {
		cout << "Sorry, but a unit you entered is not available, or does not exist.  Please check your units and try again" << endl;
		}
		cout << "Do you want to convert another temperature? (Y == YES, N = NO)" << endl;
		cin >> continueLoop;
		continueLoop = toupper(continueLoop);
	}
	return 0;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
