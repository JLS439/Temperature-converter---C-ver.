// TempConvert.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
using namespace std;
long double FtoC(long double tempKnown);
long double FtoK(long double tempKnown);
long double CtoF(long double tempKnown);
long double CtoK(long double tempKnown);
long double CtoF(long double tempKnown);
long double KtoF(long double tempKnown);
long double KtoC(long double tempKnown);
long double RtoC(long double tempKnown);
long double RtoF(long double tempKnown);
long double RtoK(long double tempKnown);
long double FtoR(long double tempKnown);
long double KtoR(long double tempKnown);
long double CtoR(long double tempKnown);
long double FtoRA(long double tempKnown);
long double CtoRA(long double tempKnown);
long double KtoRA(long double tempKnown);
long double RtoRA(long double tempKnown);
long double RAtoF(long double tempKnown);
long double RAtoC(long double tempKnown);
long double RAtoK(long double tempKnown);
long double RAtoR(long double tempKnown);
long double FtoN(long double tempKnown);
long double CtoN(long double tempKnown);
long double KtoN(long double tempKnown);
long double RtoN(long double tempKnown);
long double RAtoN(long double tempKnown);
long double NtoF(long double tempKnown);
long double NtoC(long double tempKnown);
long double NtoK(long double tempKnown);
long double NtoR(long double tempKnown);
long double NtoRA(long double tempKnown);

int main()
{
	char continueLoop = 'Y';
	long double temporary = 0;
	long double tempKnown; //numerical unit for conversion
	char tempKnownUnit = 'K'; //Unit for known temperature
	long double resultTemp = 0; // numerical value for result of conversion 
	char resultTempUnit = 'F'; //unit for display of conversion result
	cout << "Please use an UPPERCASE letter for each unit input!" << endl;
	for (int i = 0; i <= 2; i++) {
		cout << endl;
	}
	while (continueLoop == 'Y') {
		cout << "Please select starting unit (F = Fahrenheit, C= Celcius, K= Kelvin, R= Reaumur, A= Rankine, N = Newton) " << endl;
		cin >> tempKnownUnit;
		cout << tempKnownUnit << " is the starting unit for conversion." << endl;

		cout << "Please input a temperature in " << tempKnownUnit << endl;
		cin >> tempKnown;

		cout << "Please select resulting unit (F = Fahrenheit, C= Celcius, K= Kelvin, R= Reaumur, A= Rankine, N = Newton)" << endl;
		cin >> resultTempUnit;
			cout << "result will be in " << resultTempUnit << endl;

		if (tempKnownUnit == 'F' && resultTempUnit == 'K') {
			resultTemp = FtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'F') {
			resultTemp = CtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'K') {
			resultTemp = CtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'C') {
			resultTemp = KtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'C') {
			resultTemp = FtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'F') {
			resultTemp = KtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'C') {
			resultTemp = RtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'F') {
			resultTemp = RtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'K') {
			resultTemp = RtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'R') {
			resultTemp = CtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'R') {
			resultTemp = KtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'R') {
			resultTemp = FtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'A') {
			resultTemp = FtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'F') {
			resultTemp = RAtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'A') {
			resultTemp = CtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'A') {
			resultTemp = KtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'A') {
			resultTemp = RtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'C') {
			resultTemp = RAtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'K') {
			resultTemp = RAtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'R') {
			resultTemp = RAtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'F' && resultTempUnit == 'N') {
			resultTemp = FtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'C' && resultTempUnit == 'N') {
			resultTemp = CtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'K' && resultTempUnit == 'N') {
			resultTemp = KtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'R' && resultTempUnit == 'N') {
			resultTemp = RtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'A' && resultTempUnit == 'N') {
			resultTemp = RAtoN(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'F') {
			resultTemp = NtoF(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'C') {
			resultTemp = NtoC(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'K') {
			resultTemp = NtoK(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'R') {
			resultTemp = NtoR(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == 'N' && resultTempUnit == 'A') {
			resultTemp = NtoRA(tempKnown);
			cout << "Your temperature of " << tempKnown << " " << tempKnownUnit << " converts to " << resultTemp << " " << resultTempUnit << endl;
		}
		else if (tempKnownUnit == resultTempUnit) {
		cout << "Whoops!  You entered the same unit twice!  Therefore, the temperatures are the same when 'converted'." << endl;
		}
		else {
		cout << "Sorry, but a unit you entered is not available, or does not exist.  Please check your units and try again" << endl;
		}
		cout << "Do you want to convert another temperature? (Y == YES, N = NO)" << endl;
		cin >> continueLoop;
	}
	return 0;
}
long double FtoK(long double tempKnown) {
	long double temporary = FtoC(tempKnown);
	double resultTemp = temporary + 273.15;
	return resultTemp;
}
long double CtoF(long double tempKnown) {
	long double resultTemp = (tempKnown * (9.0 / 5)) + 32;
	return resultTemp;
}
long double CtoK(long double tempKnown) {
	double resultTemp = tempKnown + 273.15;
	return resultTemp;
}
long double KtoF(long double tempKnown) {
	long double temporary = tempKnown - 273.15;
	long double resultTemp = CtoF(temporary);
	return resultTemp;
}
long double KtoC(long double tempKnown) {
	double resultTemp = tempKnown - 273.15;
	return resultTemp;
}
long double FtoC(long double tempKnown) {
	double resultTemp = ((tempKnown - 32)*5.0) / 9;
	return resultTemp;
}
long double RtoC(long double tempKnown) {
	long double resultTemp = tempKnown * (5.0 / 4);
	return resultTemp;
}
long double RtoK(long double tempKnown) {
	long double temporary = RtoC(tempKnown);
	long double resultTemp = CtoK(temporary);
	return resultTemp;
}
long double RtoF(long double tempKnown) {
	long double temporary = RtoC(tempKnown);
	long double resultTemp = CtoF(temporary);
	return resultTemp;
}
long double FtoR(long double tempKnown) {
	long double temporary = FtoC(tempKnown);
	long double resultTemp = CtoR(temporary);
	return resultTemp;
}
long double KtoR(long double tempKnown) {
	long double temporary = KtoC(tempKnown);
	long double resultTemp = CtoR(temporary);
	return resultTemp;
}
long double CtoR(long double tempKnown) {
	long double resultTemp = tempKnown * (4.0 / 5);
	return resultTemp;
}
long double FtoRA(long double tempKnown) {
	long double resultTemp = tempKnown + 459.67;
	return resultTemp;
}
long double CtoRA(long double tempKnown) {
	long double temporary = CtoF(tempKnown);
	long double resultTemp = FtoRA(temporary);
	return resultTemp;
}
long double KtoRA(long double tempKnown) {
	double temporary = KtoF(tempKnown);
	double resultTemp = FtoRA(temporary);
	return resultTemp;
}
long double RtoRA(long double tempKnown) {
	long double temporary = RtoF(tempKnown);
	long double resultTemp = FtoRA(tempKnown);
	return resultTemp;
}
long double RAtoF(long double tempKnown) {
	long double resultTemp = tempKnown - 459.57;
	return resultTemp;
}
long double RAtoC(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoC(temporary);
	return resultTemp;
}
long double RAtoK(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoK(temporary);
	return resultTemp;
}
long double RAtoR(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoR(temporary);
	return resultTemp;
}
long double FtoN(long double tempKnown) {
	long double resultTemp = (((tempKnown - 32) * 11.0) / 60);
	return resultTemp;
}
long double CtoN(long double tempKnown) {
	long double temporary = CtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double KtoN(long double tempKnown) {
	long double temporary = KtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double RtoN(long double tempKnown) {
	long double temporary = RtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double RAtoN(long double tempKnown) {
	long double temporary = RAtoF(tempKnown);
	long double resultTemp = FtoN(temporary);
	return resultTemp;
}
long double NtoF(long double tempKnown) {
	long double resultTemp = (((tempKnown *60.0) / 11) + 32);
	return resultTemp;
}
long double NtoC(long double tempKnown) {
	long double temporary = NtoF(tempKnown);
	long double resultTemp = FtoC(temporary);
	return resultTemp;
}
long double NtoK(long double tempKnown) {
	long double temporary = NtoF(tempKnown);
	long double resultTemp = FtoK(temporary);
	return resultTemp;
}
long double NtoR(long double tempKnown) {
	long double temporary = NtoF(tempKnown);
	long double resultTemp = FtoR(temporary);
	return resultTemp;
}
long double NtoRA(long double tempKnown) {
	double temporary = NtoF(tempKnown);
	double resultTemp = FtoRA(temporary);
	return resultTemp;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
